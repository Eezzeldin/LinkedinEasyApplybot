#!/usr/bin/python
#
# Copyright 2011 Webdriver_name committers
# Copyright 2011 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import subprocess
from subprocess import PIPE
import time
import os
import signal
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common import utils


class Service(object):

    MISSING_TEXT = '''Unable to find the Selenium server jar.  Please download the standalone  
                    server from http://code.google.com/p/selenium/downloads/list and set the
                    SELENIUM_SERVER_JAR environmental variable to its location.  More info at
                    http://code.google.com/p/selenium/wiki/OperaDriver.'''

    def __init__(self, jar, port=0):
        self.port = port
        self.path = jar 
        if self.port == 0:
            self.port = utils.free_port()

    def start(self):
        """ Starts the ChromeDriver Service. 
            @Exceptions
                WebDriverException : Raised either when it can't start the service
                    or when it can't connect to the service"""
        try:
            self.process = subprocess.Popen([self.path, "--port=%d" % self.port],
                    stdout=PIPE, stderr=PIPE)
        except:
            raise WebDriverException(self.MISSING_TEXT)
        count = 0
        while not utils.is_connectable(self.port):
            count += 1
            time.sleep(1)
            if count == 30:
                 raise WebDriverException("Can not connect to the ChromeDriver")
                
    @property
    def service_url(self):
        """ Gets the url of the ChromeDriver Service """
        return "http://localhost:%d" % self.port

    def stop(self):
        """ Tells the ChromeDriver to stop and cleans up the process """
        #If its dead dont worry
        if self.process is None:
            return

        #Tell the Server to die!
        import urllib2
        urllib2.urlopen("http://127.0.0.1:%d/shutdown" % self.port)
        count = 0
        while not utils.is_connectable(self.port):
            if count == 30:
               break 
            count += 1
            time.sleep(1)
        
        #Tell the Server to properly die in case
        try:
            if self.process:
                os.kill(self.process.pid, signal.SIGTERM)
                os.wait()
        except AttributeError:
            # kill may not be available under windows environment
            pass
